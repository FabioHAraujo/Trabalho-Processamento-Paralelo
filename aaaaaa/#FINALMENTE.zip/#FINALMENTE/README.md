# COMO EXECUTAR O PROGRAMA:

Estando na pasta onde há os fontes .erl, digite no terminal:
erl
Isso abrirá o interpretador do Erlang.

Dentro do interpretador, digite:
c(master), c(buffer), c(producer), c(consumer), c(item).
e aperte enter. Isso compilará os códigos.

Após, execute o master usando:
master:init().

Insira o número do produtores e o número de consumidores, e observe a execução do código.